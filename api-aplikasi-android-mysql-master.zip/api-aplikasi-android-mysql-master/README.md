# API Aplikasi Android MySQL

File ini merupakan API untuk membuat Aplikasi Android Create, Read, Update dan Delete dengan menggunakan Database MySQL.